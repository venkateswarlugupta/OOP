package behind.exceptions;

public class BoogieRemovedDueToMaintenance extends Exception {
    @Override
    public String toString() {
        return "We will bring this boogie sooner";
    }
}
