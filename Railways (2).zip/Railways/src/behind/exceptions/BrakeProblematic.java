package behind.exceptions;

public class BrakeProblematic extends Exception{
    @Override
    public String toString() {
        return "Brake is fixed";
    }
}
