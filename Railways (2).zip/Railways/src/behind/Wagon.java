package behind;

public interface Wagon {
}