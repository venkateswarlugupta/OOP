package assignment3.h_mart;

import java.io.*;

public class ManagingData {
    public static BufferedReader readFromUser = new BufferedReader(new InputStreamReader(System.in));

    public static void addCategories() throws IOException {
        FileWriter fileWriter = new FileWriter("src\\assignment3\\h_mart\\categories.txt", true);
        System.out.println("Enter category name : ");
        String newCategory = readFromUser.readLine();
        fileWriter.write(newCategory + '\n');
        fileWriter.close();
        FileWriter fileWriter1 = new FileWriter("src\\assignment3\\h_mart\\categories\\" + newCategory + ".txt");
        fileWriter1.write("");
        fileWriter1.close();
    }

    public static void addItemsToACategory(String categoryName) throws IOException {
        File file1 = new File("src\\assignment3\\h_mart\\categories.txt");
        boolean isCategoryPresent = false;
        FileReader fileReader = new FileReader(file1);
        BufferedReader br = new BufferedReader(fileReader);
        String category;
        while ((category = br.readLine()) != null) {
            if (category.equals(categoryName)) {
                isCategoryPresent = true;
                break;
            }
        }
        if (isCategoryPresent) {
            System.out.println("Enter itemName, ID, brand, mfgYear, mfgMonth, mfgDate, noOfMonthsToExpire, noOfDaysTOExpire, price, quantity");
            System.out.println("Enter all fields in a line, use delimiter :: to separate fields");
            //For extra attributes, give field name and value separated by -
            String input = readFromUser.readLine()+'\n';
            FileWriter fileWriter = new FileWriter("src\\assignment3\\h_mart\\categories\\" + categoryName + ".txt", true);
            fileWriter.write(input);
            fileWriter.close();
        } else {
            System.out.println(categoryName + " is not present..\nFirstly create this category");
        }
    }
}

class Mainnn {
    public static void main(String[] args) throws IOException {
        ManagingData.addCategories();
        ManagingData.addItemsToACategory("MilkProducts");
    }
}