package behind.exceptions;

public class BrokenGlass extends Exception {
    public String toString() {
        return "We will replace the glass";
    }
}