package behind.exceptions;

public class ChargingSocketIssue extends Exception{
    @Override
    public String toString() {
        return "Electrician will repair";
    }
}
