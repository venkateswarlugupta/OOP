package behind;

public class Pantry implements Wagon{
    void displayMenu(){
        System.out.println("IRCTC CATERING\n\n" +
                "foods and drinks");
    }
}
