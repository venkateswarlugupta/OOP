package behind.exceptions;

public class NoMirror extends Throwable{
    @Override
    public String toString() {
        return "We will place a Mirror";
    }
}
