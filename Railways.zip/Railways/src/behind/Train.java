package behind;

import java.util.ArrayList;
import java.util.List;

public class Train {
//    static List<Wagon> train=new ArrayList<>();

    public static void main(String[] args) {
        List<Boogie> train=new ArrayList<>();
        Boogie one=new Boogie( 1,"1A",10,2);
        train.add(one);
        train.add(new Boogie( 2,"2A",10,3));
        train.add(new Boogie( 3,"2A",10,3));
        train.add(new Boogie( 4,"3A",10,4));
        train.add(new Boogie( 5,"3A",10,4));
        train.add(new Boogie( 6,"3A",10,4));
        //train.add(new Pantry());
        train.add(new Boogie( 8,"SL",18,4));
        System.out.println(train.get(1));
        //train.get(1);

        /*train.add(new Boogie( 9,"SL",18,4));
        train.add(new Boogie( 10,"SL",18,4));
        train.add(new Boogie( 11,"SL",18,4));
        train.add(new Boogie( 12,"SL",18,4));
        train.add(new Boogie( 13,"SL",18,4));
        train.add(new Boogie( 14,"SL",18,4));
        train.add(new Boogie( 15,"SL",18,4));
        Boogie boogie=new Boogie(1,"2A",18,4);*/
    }
}
class Student{
    int roll;
    Student(int roll){
        this.roll=roll;
    }
}
class Class{
    List<Student> students;
    Class(){
        students=new ArrayList<>();
    }
    void addingStudents(){
        students.add(new Student(1));
        students.add(new Student(2));
    }
}
class College{
    static List<Class> classes=new ArrayList<>();

    public static void main(String[] args) {
        classes.add(new Class());
        classes.add(new Class());
        classes.add(new Class());
        classes.get(1).students.get(1);
    }
}