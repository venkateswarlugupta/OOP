package behind;

public class Pantry extends Wagonn{
    void displayMenu(){
        System.out.println("IRCTC CATERING\n\n" +
                "foods and drinks");
    }
}
