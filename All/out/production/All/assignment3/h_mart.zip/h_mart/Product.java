package assignment3.h_mart;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;

public class Product {
    String category;
    String name;
    String ID;
    String brand;
    Calendar mfg;
    Calendar exp;
    double price;
    int quantity;
    Product(){
        //
    }
    public Product(String category, String name, String ID, String brand, Calendar mfg, int noOfMonthsToExpire,int noOfDaysTOExpire, double price, int quantity) {
        this.category=category;
        this.name = name;
        this.ID = ID;
        this.brand = brand;
        this.mfg = mfg;
        this.exp = mfg;
        this.exp.add(Calendar.MONTH, noOfMonthsToExpire);
        this.exp.add(Calendar.DATE,noOfDaysTOExpire);
        this.price = price;
        this.quantity = quantity;
    }
    LinkedHashMap<String, String> attributes = new LinkedHashMap<>();
}

class Mainn {
    public static void main(String[] args) {
        Product soap=new Product();
        Calendar c=new GregorianCalendar();
        c.add(Calendar.MONTH,-3);
        String mfdate= c.get(Calendar.YEAR) +"-"+c.get(Calendar.MONTH);
        c.add(Calendar.MONTH,9);
        String exdate= c.get(Calendar.YEAR) +"-"+c.get(Calendar.MONTH);
        soap.attributes.put("Name","Soap");
        soap.attributes.put("ID", "HM9854");
        soap.attributes.put("Brand", "Mysore Sandal");
        soap.attributes.put("Mfg Date",mfdate);
        soap.attributes.put("Exp Date",exdate);
        soap.attributes.put("Price",String.valueOf(38));
        soap.attributes.put("Quantity",Integer.toString(10));
        for(String i:soap.attributes.keySet()){
            System.out.println(i+" : "+soap.attributes.get(i));
        }
    }
}