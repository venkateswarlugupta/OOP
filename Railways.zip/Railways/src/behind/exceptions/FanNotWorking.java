package behind.exceptions;

public class FanNotWorking extends Exception{
    @Override
    public String toString() {
        return "We will fix this fan";
    }
}
