package behind.exceptions;

public class BedRollMissing extends Throwable{
    @Override
    public String toString() {
        return "Someone have shopped a bed roll :-|";
    }
}
