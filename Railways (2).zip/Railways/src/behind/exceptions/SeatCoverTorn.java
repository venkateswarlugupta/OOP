package behind.exceptions;

public class SeatCoverTorn extends Exception{
    @Override
    public String toString() {
        return "we will change cover";
    }
}
