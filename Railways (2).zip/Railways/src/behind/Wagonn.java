package behind;

import java.util.LinkedList;
import java.util.List;

public class Wagonn {
    List<List<Seat>> seats = new LinkedList<>();

}
