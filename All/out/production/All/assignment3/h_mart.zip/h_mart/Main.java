package assignment3.h_mart;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.StringTokenizer;

public class Main {
    public static List<Product> inStock = new ArrayList<>();
    public static List<Product> outOfStock = new ArrayList<>();
    public static List<Product> fastFilling = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        FileReader readCategory = new FileReader("src\\assignment3\\h_mart\\categories.txt");
        BufferedReader br = new BufferedReader(readCategory);
        String category;
        while ((category = br.readLine()) != null) {
            FileReader readItems = new FileReader("src\\assignment3\\h_mart\\categories\\" + category + ".txt");
            BufferedReader br1 = new BufferedReader(readItems);
            String itemStr;
            while ((itemStr = br1.readLine()) != null) {
                StringTokenizer st = new StringTokenizer(itemStr, ":");
                Product item = new Product(
                        category,
                        st.nextToken(),
                        st.nextToken(),
                        st.nextToken(),
                        new GregorianCalendar(Integer.parseInt(st.nextToken()), Integer.parseInt(st.nextToken()), Integer.parseInt(st.nextToken())),
                        Integer.parseInt(st.nextToken()),
                        Integer.parseInt(st.nextToken()),
                        Double.parseDouble(st.nextToken()),
                        Integer.parseInt(st.nextToken())
                );
                while (st.hasMoreTokens()) {
                    StringTokenizer extra = new StringTokenizer(st.nextToken(), "-");
                    item.attributes.put(extra.nextToken(), extra.nextToken());
                }
                if (item.quantity > 5) {
                    inStock.add(item);
                } else if (item.quantity > 0) {
                    fastFilling.add(item);
                } else {
                    outOfStock.add(item);
                }
                System.out.println(item.attributes);
            }
        }
        System.out.println("\nIn stock \n");
        if (inStock.size() > 0) {
            for (Product product : inStock)
                System.out.println(product.name);
        }
        if (fastFilling.size() > 0) {
            System.out.println("\nFast Filling \n");
            for (Product product : fastFilling)
                System.out.println(product.name);
        }
        if (outOfStock.size() > 0) {
            System.out.println("\nOut of Stock\n");
            for (Product product : outOfStock)
                System.out.println(product.name);
        }
    }
}