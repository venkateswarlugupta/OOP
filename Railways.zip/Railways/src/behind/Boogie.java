package behind;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Boogie implements Wagon {
    int boogieNo;
    String tire;
    int rows;
    int columns;
    byte seatNo = 1;
    byte availableSeats;
    List<List<Seat>> seats = new ArrayList<List<Seat>>();

    Boogie(int boogieNo, String tire, int rows, int columns) {
        this.boogieNo = boogieNo;
        this.tire = tire;
        this.rows = rows;
        this.columns = columns;
        availableSeats = (byte) (rows * columns);
        for (byte column, row = 0; row < rows; row++) {
            seats.add(new ArrayList<>());
            for (column = 0; column < columns; column++) {
                seats.get(row).add(new Seat(seatNo++, getPosition()));
            }
        }
    }

    boolean bookSeats(byte noOfSeats) {
        try {
            while (noOfSeats-- > 0) {
                seats.get((rows * columns - availableSeats) % rows).get(columns - noOfSeats).bookNow();
                //max no of seats allowed to book is size of 2*columns
                availableSeats--;
            }
            System.out.println("Successfully booked");
            return true;
        } catch (Exception e) {
            System.out.println("Unsuccessful to book");
            return false;
        }
    }

    boolean cancelSeats(byte noOfSeats, ArrayList<Byte> seatNumbers) {
        try {
            while (noOfSeats-- > 0) {
                int seatNumber = seatNumbers.get(noOfSeats);
                seats.get(seatNumber % rows).get(columns - seatNumber % rows).cancelNow();
            }
            System.out.println("Successfully cancelled");
            return true;
        } catch (Exception e) {
            System.out.println("Unsuccessful while cancelling ");
            return false;
        }
    }

    StringTokenizer getPosition() {
        if (tire.equals("1A")) {
            if (seatNo % 2 == 0) {
                return new StringTokenizer("Aisle::Upper", ":");
            } else {
                return new StringTokenizer("Window::Lower", ":");
            }
        } else if (tire.equals("2A")) {
            if (seatNo % 3 == 0 || seatNo % 3 == 1) {
                return new StringTokenizer("Window::Lower", ":");
            } else {
                return new StringTokenizer("Aisle::Upper", ":");
            }
        } else {
            if (seatNo % 4 == 0 || (seatNo - 1) % 4 == 0) {
                return new StringTokenizer("Window::Lower", ":");
            } else if (seatNo % 2 == 0) {
                return new StringTokenizer("Aisle::Upper", ":");
            } else {
                return new StringTokenizer("Middle::Middle", ":");
            }
        }
    }
}